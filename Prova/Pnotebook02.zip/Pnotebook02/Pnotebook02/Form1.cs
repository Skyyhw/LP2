﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pnotebook02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[,] notebook = new int[2, 3];
            string auxiliar = "";
            string saida = "";


            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (!int.TryParse(Interaction.InputBox("Digite o modelo "), out notebook[i, j]))
                    {
                        MessageBox.Show("Modelo inválido!");
                        j--;
                    }
                    else
                    {
                        if (notebook[i, j] <= 0 || notebook[i, j] > 3)
                        {
                            MessageBox.Show("Modelo inválido!");
                            j--;
                        }
                        else
                        {
                            if (notebook[i, j] == 1) ;
                            MessageBox.Show("Notebook 1:");
                        }
                    }
                    auxiliar = Interaction.InputBox("Digite o valor", "Entrada de Dados");

                    if (!int.TryParse(auxiliar, out notebook[i,j]))
                    {
                        MessageBox.Show("Valor Inválido");
                        i--;
                    }
                    else
                    {
                        saida = auxiliar + saida;
                    }
                }
            }
        }
      
            

        private void btnLimpar_Click(object sender, EventArgs e)
        {
          
        }
    }
}
