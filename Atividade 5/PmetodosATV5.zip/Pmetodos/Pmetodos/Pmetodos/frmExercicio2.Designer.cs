﻿namespace Pmetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCompara = new Button();
            btnInserir1 = new Button();
            lblPalavra1 = new Label();
            lblPalavra2 = new Label();
            btnInserirAst = new Button();
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            SuspendLayout();
            // 
            // btnCompara
            // 
            btnCompara.Location = new Point(11, 180);
            btnCompara.Name = "btnCompara";
            btnCompara.Size = new Size(165, 45);
            btnCompara.TabIndex = 0;
            btnCompara.Text = "Comparar";
            btnCompara.UseVisualStyleBackColor = true;
            btnCompara.Click += btnCompara_Click;
            // 
            // btnInserir1
            // 
            btnInserir1.Font = new Font("Segoe UI", 7F);
            btnInserir1.Location = new Point(11, 243);
            btnInserir1.Name = "btnInserir1";
            btnInserir1.Size = new Size(165, 45);
            btnInserir1.TabIndex = 1;
            btnInserir1.Text = "Inserir Primeiro no\r\nMeio do Segundo";
            btnInserir1.UseVisualStyleBackColor = true;
            btnInserir1.Click += btnInserir1_Click;
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(11, 46);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(73, 21);
            lblPalavra1.TabIndex = 2;
            lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(11, 96);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(73, 21);
            lblPalavra2.TabIndex = 3;
            lblPalavra2.Text = "Palavra 2";
            // 
            // btnInserirAst
            // 
            btnInserirAst.Location = new Point(11, 305);
            btnInserirAst.Name = "btnInserirAst";
            btnInserirAst.Size = new Size(165, 45);
            btnInserirAst.TabIndex = 4;
            btnInserirAst.Text = "Inserir Asterisco";
            btnInserirAst.UseVisualStyleBackColor = true;
            btnInserirAst.Click += btnInserirAst_Click;
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(96, 44);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(349, 29);
            txtPalavra1.TabIndex = 5;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(96, 96);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(349, 29);
            txtPalavra2.TabIndex = 6;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(720, 378);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Controls.Add(btnInserirAst);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Controls.Add(btnInserir1);
            Controls.Add(btnCompara);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCompara;
        private Button btnInserir1;
        private Label lblPalavra1;
        private Label lblPalavra2;
        private Button btnInserirAst;
        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
    }
}