﻿namespace Pmetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btnContaNum = new Button();
            btnPrimeiroBranco = new Button();
            btnContaLetras = new Button();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(64, 12);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(575, 251);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btnContaNum
            // 
            btnContaNum.Location = new Point(23, 297);
            btnContaNum.Name = "btnContaNum";
            btnContaNum.Size = new Size(193, 71);
            btnContaNum.TabIndex = 1;
            btnContaNum.Text = "Conta Números";
            btnContaNum.UseVisualStyleBackColor = true;
            btnContaNum.Click += btnContaNum_Click;
            // 
            // btnPrimeiroBranco
            // 
            btnPrimeiroBranco.Location = new Point(257, 297);
            btnPrimeiroBranco.Name = "btnPrimeiroBranco";
            btnPrimeiroBranco.Size = new Size(193, 71);
            btnPrimeiroBranco.TabIndex = 2;
            btnPrimeiroBranco.Text = "Primeiro Char Branco";
            btnPrimeiroBranco.UseVisualStyleBackColor = true;
            btnPrimeiroBranco.Click += btnPrimeiroBranco_Click;
            // 
            // btnContaLetras
            // 
            btnContaLetras.Location = new Point(490, 297);
            btnContaLetras.Name = "btnContaLetras";
            btnContaLetras.Size = new Size(193, 71);
            btnContaLetras.TabIndex = 3;
            btnContaLetras.Text = "Contar Letras";
            btnContaLetras.UseVisualStyleBackColor = true;
            btnContaLetras.Click += btnContaLetras_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnContaLetras);
            Controls.Add(btnPrimeiroBranco);
            Controls.Add(btnContaNum);
            Controls.Add(rchtxtFrase);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btnContaNum;
        private Button btnPrimeiroBranco;
        private Button btnContaLetras;
    }
}