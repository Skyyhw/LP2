﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numero1, numero2;

            if (!int.TryParse(txtNumero1.Text, out numero1) || (!int.TryParse(txtNumero2.Text, out numero2)))
                MessageBox.Show("Dados inválidos.");
            else if (numero2 <= numero1)
                MessageBox.Show("Dados inválidos");
            else
            {
                    Random obj1 = new Random();
                    int sorteado = obj1.Next(numero1, numero2);
                    MessageBox.Show("Número sorteado: " + sorteado);
            }
        }
    }
}
