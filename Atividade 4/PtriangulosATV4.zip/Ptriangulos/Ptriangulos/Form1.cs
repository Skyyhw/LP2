namespace Ptriangulos
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            try
            {
                ladoA = Double.Parse(txtLadoA.Text);
                ladoB = Double.Parse(txtLadoB.Text);
                ladoC = Double.Parse(txtLadoC.Text);

                if (ladoA <= Math.Abs(ladoB - ladoC) || ladoA >= ladoB + ladoC || ladoA <= 0)
                {
                    MessageBox.Show("Tamanho de lados inv�lidos.");
                }
                else if (ladoB <= Math.Abs(ladoA - ladoC) || ladoB >= ladoA + ladoC || ladoB <= 0)
                {
                    MessageBox.Show("Tamanho de lados inv�lidos.");
                }
                else if (ladoC <= Math.Abs(ladoA - ladoB) || ladoC >= ladoA + ladoB || ladoC <= 0)
                {
                    MessageBox.Show("Tamanho de lados inv�lidos.");
                }
                else
                {
                    if (ladoA == ladoB && ladoB == ladoC)
                        MessageBox.Show("O tri�ngulo � equilatero.");
                    else if (ladoA != ladoB && ladoB != ladoC && ladoC != ladoA)
                        MessageBox.Show("O tri�ngulo � escaleno.");
                    else
                        MessageBox.Show("O tri�ngulo � is�celes.");
                }
            }
            catch
            {
                MessageBox.Show("Erro de convers�o. Verifique se os lados s�o n�meros e maiores que 0.");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            DialogResult = MessageBox.Show("Voc� deseja sair?", "Confirma��o sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DialogResult == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}