﻿namespace Ptriangulos
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtLadoA = new TextBox();
            lblLadoA = new Label();
            lblLadoB = new Label();
            lblLadoC = new Label();
            txtLadoB = new TextBox();
            txtLadoC = new TextBox();
            btnExecutar = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // txtLadoA
            // 
            txtLadoA.Location = new Point(140, 35);
            txtLadoA.Name = "txtLadoA";
            txtLadoA.Size = new Size(207, 31);
            txtLadoA.TabIndex = 0;
            // 
            // lblLadoA
            // 
            lblLadoA.AutoSize = true;
            lblLadoA.Location = new Point(44, 38);
            lblLadoA.Name = "lblLadoA";
            lblLadoA.Size = new Size(68, 25);
            lblLadoA.TabIndex = 1;
            lblLadoA.Text = "Lado A";
            // 
            // lblLadoB
            // 
            lblLadoB.AutoSize = true;
            lblLadoB.Location = new Point(44, 86);
            lblLadoB.Name = "lblLadoB";
            lblLadoB.Size = new Size(66, 25);
            lblLadoB.TabIndex = 2;
            lblLadoB.Text = "Lado B";
            // 
            // lblLadoC
            // 
            lblLadoC.AutoSize = true;
            lblLadoC.Location = new Point(44, 134);
            lblLadoC.Name = "lblLadoC";
            lblLadoC.Size = new Size(67, 25);
            lblLadoC.TabIndex = 3;
            lblLadoC.Text = "Lado C";
            // 
            // txtLadoB
            // 
            txtLadoB.Location = new Point(140, 86);
            txtLadoB.Name = "txtLadoB";
            txtLadoB.Size = new Size(207, 31);
            txtLadoB.TabIndex = 4;
            // 
            // txtLadoC
            // 
            txtLadoC.Location = new Point(140, 134);
            txtLadoC.Name = "txtLadoC";
            txtLadoC.Size = new Size(207, 31);
            txtLadoC.TabIndex = 5;
            // 
            // btnExecutar
            // 
            btnExecutar.Location = new Point(44, 234);
            btnExecutar.Name = "btnExecutar";
            btnExecutar.Size = new Size(151, 71);
            btnExecutar.TabIndex = 6;
            btnExecutar.Text = "Executar";
            btnExecutar.UseVisualStyleBackColor = true;
            btnExecutar.Click += btnExecutar_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(231, 234);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(151, 71);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(424, 234);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(151, 71);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1073, 623);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnExecutar);
            Controls.Add(txtLadoC);
            Controls.Add(txtLadoB);
            Controls.Add(lblLadoC);
            Controls.Add(lblLadoB);
            Controls.Add(lblLadoA);
            Controls.Add(txtLadoA);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtLadoA;
        private Label lblLadoA;
        private Label lblLadoB;
        private Label lblLadoC;
        private TextBox txtLadoB;
        private TextBox txtLadoC;
        private Button btnExecutar;
        private Button btnLimpar;
        private Button btnSair;
    }
}
