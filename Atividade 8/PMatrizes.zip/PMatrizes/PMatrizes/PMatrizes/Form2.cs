﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            string saida = "";
            int numCaracteres;

            for (int i = 0; i < 10; i++)
            {
                nomes[i] = Interaction.InputBox("Digite Nomes");

                numCaracteres = 0;
                foreach (char c in nomes[i].ToString())
                {   
                    if (c != ' ')
                        numCaracteres++;
                }
               
                saida = "O nome " + nomes[i] + " tem " + numCaracteres + " caracteres.";
                lstDestino.Items.Add(saida);
            }
        }
    }
}
