﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite números", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor Inválido");
                    i--;
                }
                else
                {
                    saida = auxiliar + saida;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = String.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };

            lista.Remove("Ótávio");

            string auxiliar = "";
            foreach (string s in lista)
            {
                auxiliar += s;
            }

            MessageBox.Show(auxiliar);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            string saida = "";

            double[,] notas = new double[20, 3];

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (!Double.TryParse(Interaction.InputBox("Digite Notas: "), out notas[i,j]))
                    {
                        MessageBox.Show("Nota inválida.");
                        j--;
                    }
                    else
                    {   
                        if (notas[i,j] < 0 || notas[i,j] > 10)
                        {
                            MessageBox.Show("Nota inválida. ");
                            j--;
                        }
                    }
                }

                saida = saida + "Média do aluno " + (i+1) + " : " + (notas[i, 0] + notas[i, 1] + notas[i, 2])/3 + "\n";
            }

            MessageBox.Show(saida);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form2>().Count() > 0)
            {
                Application.OpenForms["Form2"].BringToFront();
            }
            else
            {
                Form2 obj2 = new Form2();
                obj2.Show();
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3>().Count() > 0)
            {
                Application.OpenForms["Form3"].BringToFront();
            }
            else
            {
                Form3 obj2 = new Form3();
                obj2.Show();
            }
        }
    }
}
