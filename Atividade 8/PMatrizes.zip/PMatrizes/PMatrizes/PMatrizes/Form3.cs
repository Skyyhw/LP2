﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[] gabarito = new char[10] {'A','C','B','E','D','B','C','A','E','D'};
            char[,] alunos = new char[4 , 10];
            string resposta, imprimir = "";

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    resposta = Interaction.InputBox("Selecione uma alternativa: A, B, C, D, E");
                    if (!Char.TryParse(resposta, out alunos[i, j]))
                    {
                        MessageBox.Show("Resposta inválida.");
                        j--;
                    }
                    else
                    {
                        if ((alunos[i, j] >= 65 && alunos[i, j] <= 69) || (alunos[i, j] >= 97 && alunos[i, j] <= 101))
                        {
                            if (Char.ToUpper(alunos[i, j]) == gabarito[j])
                            {
                                imprimir = "O aluno " + (i + 1) + " acertou a questão " + (j + 1) + " - Era " + gabarito[j] + ", escolheu " + Char.ToUpper(alunos[i, j]);
                                lstDestino.Items.Add(imprimir);
                            }
                            else
                            {
                                imprimir = "O aluno " + (i + 1) + " errou a questão " + (j + 1) + " - Era " + gabarito[j] + ", escolheu " + Char.ToUpper(alunos[i, j]);
                                lstDestino.Items.Add(imprimir);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Resposta inválida.");
                            j--;
                        }
                    }
                }
            }
        }
    }
}
