﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPesoAtual = new MaskedTextBox();
            txtAltura = new MaskedTextBox();
            txtIMC = new TextBox();
            lblPesoAtual = new Label();
            lblAltura = new Label();
            lblImc = new Label();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // txtPesoAtual
            // 
            txtPesoAtual.Location = new Point(138, 12);
            txtPesoAtual.Mask = "900.00";
            txtPesoAtual.Name = "txtPesoAtual";
            txtPesoAtual.Size = new Size(362, 31);
            txtPesoAtual.TabIndex = 0;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(138, 85);
            txtAltura.Mask = "0.00";
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(362, 31);
            txtAltura.TabIndex = 1;
            // 
            // txtIMC
            // 
            txtIMC.Enabled = false;
            txtIMC.Location = new Point(138, 163);
            txtIMC.Name = "txtIMC";
            txtIMC.Size = new Size(362, 31);
            txtIMC.TabIndex = 2;
            // 
            // lblPesoAtual
            // 
            lblPesoAtual.AutoSize = true;
            lblPesoAtual.Location = new Point(12, 18);
            lblPesoAtual.Name = "lblPesoAtual";
            lblPesoAtual.Size = new Size(95, 25);
            lblPesoAtual.TabIndex = 3;
            lblPesoAtual.Text = "Peso Atual";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(48, 88);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(59, 25);
            lblAltura.TabIndex = 4;
            lblAltura.Text = "Altura";
            // 
            // lblImc
            // 
            lblImc.AutoSize = true;
            lblImc.Location = new Point(48, 163);
            lblImc.Name = "lblImc";
            lblImc.Size = new Size(44, 25);
            lblImc.TabIndex = 5;
            lblImc.Text = "IMC";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(48, 262);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(223, 77);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(277, 262);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(223, 77);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(506, 262);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(223, 77);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(lblImc);
            Controls.Add(lblAltura);
            Controls.Add(lblPesoAtual);
            Controls.Add(txtIMC);
            Controls.Add(txtAltura);
            Controls.Add(txtPesoAtual);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaskedTextBox txtPesoAtual;
        private MaskedTextBox txtAltura;
        private TextBox txtIMC;
        private Label lblPesoAtual;
        private Label lblAltura;
        private Label lblImc;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
    }
}
